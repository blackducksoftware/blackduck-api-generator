# Hub API Specification

The API specification provides information about requests and responses to/from the Hub application in a programatically consumable format

Specifications are in CSV format, using commas as delimiters and bounding all values with double-qoutes. Note that values within double-qoutes may contain commas!

## Directory layout

Directories within the archive follow the format {path}/{verb}/{minified-media-type}

* {path} is the request path on the application, starting at "api"
* {verb} is an HTTP verb, such as "GET"
* {minified-media-type} is a directory-safed version of the media type requests/responses are using per the contained specification, or "no_content" for content-less requests such as DELETE operations 

"Minified" media type to full media type relations are documented in `minified-media-types.csv` in the root of the archive

## Request Parameter Specifications

The request parameter CSV file(s) are in files called 'request-specification-parameters.csv'. Each CSV row contains (in order):

* Key - The key value of the query parameter
* Description - A general explanation of the query parameter

## Request/Response Field Specifications

The request/response field CSV file(s) are in files called 'request-specification-fields.csv' or 'response-specification-fields.csv', respectively. Each CSV row contains (in order):

* Path - The JSON property path to the described field
* Type - The JSON data type contained by the field
* Optional - "true" if the field is sparsely populated, "false" otherwise
* Description - A general explanation of the field
* Allowed Values - A CSV of the values allowed on the field. Empty if no such constraint(s) exist

## Response Link Specifications

The response link CSV file(s) are in files called 'specification-links.csv'. Each CSV row contains (in order):

* Rel - A key identifying the meaning of the link
* Optional - "true" if the link is sparsely populated, "false" otherwise
* Description - A general explanation of the link
